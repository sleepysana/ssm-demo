create
    definer = luott@`%` procedure proc_create_user(IN v_bind_email varchar(100), IN v_password varchar(40))
BEGIN
		INSERT INTO user(bind_email, bind_phone) VALUES (v_bind_email,v_password);
		IF EXISTS (SELECT * FROM user_info WHERE id = (SELECT id FROM `user` WHERE bind_email = v_bind_email)) THEN
			DELETE FROM user_info  WHERE id = (SELECT id FROM `user` WHERE bind_email = v_bind_email);
			INSERT INTO user_info (id) VALUES (( SELECT id FROM `user` WHERE bind_email = v_bind_email));
		ELSE 
			INSERT INTO user_info (id) VALUES ((SELECT id FROM `user` WHERE bind_email = v_bind_email));
		END IF;
		
		IF EXISTS (SELECT * FROM user_role WHERE id = (SELECT id FROM `user` WHERE bind_email = v_bind_email)) THEN
			DELETE FROM user_role  WHERE id = (SELECT id FROM `user` WHERE bind_email = v_bind_email);
			INSERT INTO user_role (id) VALUES ((SELECT id FROM `user` WHERE bind_email = v_bind_email));
		ELSE 
			INSERT INTO user_info (id) VALUES ((SELECT id FROM `user` WHERE bind_email = v_bind_email));
		END IF;
		COMMIT;
END;

