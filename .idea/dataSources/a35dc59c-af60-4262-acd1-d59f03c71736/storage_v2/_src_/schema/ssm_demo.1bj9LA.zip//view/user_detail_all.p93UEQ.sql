create definer = luott@`%` view user_detail_all as
select `uuir`.`id`         AS `id`,
       `uuir`.`uname`      AS `uname`,
       `uuir`.`bind_email` AS `bind_email`,
       `uuir`.`bind_phone` AS `bind_phone`,
       `uuir`.`status`     AS `status`,
       `uuir`.`head_icon`  AS `head_icon`,
       `uuir`.`gender`     AS `gender`,
       `uuir`.`birthday`   AS `birthday`,
       `uuir`.`phone`      AS `phone`,
       `uuir`.`email`      AS `email`,
       `uuir`.`addr`       AS `addr`,
       `uuir`.`reg_date`   AS `reg_date`,
       `uuir`.`role`       AS `role`,
       `urna`.`real_name`  AS `real_name`,
       `urna`.`cid`        AS `cid`,
       `urna`.`cert_type`  AS `cert_type`
from ((select `uui`.`id`         AS `id`,
              `uui`.`uname`      AS `uname`,
              `uui`.`bind_email` AS `bind_email`,
              `uui`.`bind_phone` AS `bind_phone`,
              `uui`.`status`     AS `status`,
              `uui`.`head_icon`  AS `head_icon`,
              `uui`.`gender`     AS `gender`,
              `uui`.`birthday`   AS `birthday`,
              `uui`.`phone`      AS `phone`,
              `uui`.`email`      AS `email`,
              `uui`.`addr`       AS `addr`,
              `uui`.`reg_date`   AS `reg_date`,
              `ur`.`role`        AS `role`
       from ((select `u`.`id`         AS `id`,
                     `u`.`uname`      AS `uname`,
                     `u`.`bind_email` AS `bind_email`,
                     `u`.`bind_phone` AS `bind_phone`,
                     `u`.`status`     AS `status`,
                     `ui`.`head_icon` AS `head_icon`,
                     `ui`.`gender`    AS `gender`,
                     `ui`.`birthday`  AS `birthday`,
                     `ui`.`phone`     AS `phone`,
                     `ui`.`email`     AS `email`,
                     `ui`.`addr`      AS `addr`,
                     `ui`.`reg_date`  AS `reg_date`
              from (`ssm_demo`.`user` `u`
                       left join `ssm_demo`.`user_info` `ui` on ((`u`.`id` = `ui`.`id`)))) `uui`
                left join `ssm_demo`.`user_role` `ur` on ((`uui`.`id` = `ur`.`id`)))) `uuir`
         left join `ssm_demo`.`user_real_name_auth` `urna` on ((`uuir`.`id` = `urna`.`id`)));

-- comment on column user_detail_all.id not supported: 用户id  主键

-- comment on column user_detail_all.uname not supported: 用户名(可用作登录凭据)

-- comment on column user_detail_all.bind_email not supported: 绑定邮箱(可用作登录凭据)

-- comment on column user_detail_all.bind_phone not supported: 绑定的电话号码(可用作登录凭据)

-- comment on column user_detail_all.status not supported: 状态

-- comment on column user_detail_all.head_icon not supported: 用户头像

-- comment on column user_detail_all.gender not supported: 性别(0或null:未设置, 1:男, 2:女, 3:其他性别, 4:保密)

-- comment on column user_detail_all.birthday not supported: 出生日期

-- comment on column user_detail_all.phone not supported: 联系手机(默认为绑定手机)

-- comment on column user_detail_all.email not supported: 联系邮箱(默认为绑定邮箱)

-- comment on column user_detail_all.addr not supported: 联系地址

-- comment on column user_detail_all.reg_date not supported: 注册时间(不可修改)

-- comment on column user_detail_all.role not supported: 用户角色(-1:未激活)

-- comment on column user_detail_all.real_name not supported: 用户真实名字,和user表中的uname(用户名)无关

-- comment on column user_detail_all.cid not supported: 用户身份证号/护照/学生证号 你想是什么就是什么

-- comment on column user_detail_all.cert_type not supported: 证件类型(预留用的)

